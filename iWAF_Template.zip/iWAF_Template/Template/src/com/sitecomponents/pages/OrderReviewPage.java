/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;

public class OrderReviewPage extends SitePage {

	public static final Target PRODUCT_IMAGE = new Target("product-image","//table[@class='snapshotTable']//img",Target.XPATH);
	public static final Target PRODUCT_TITLE = new Target("product-title","//table[@class='snapshotTable']//span[@class='items_title']",Target.XPATH);
	public static final Target ARRIVAL_INFORMATION = new Target("arrival-information","//td[@class='shippingArrival']",Target.XPATH);
	public static final Target QUANTITY = new Target("quantity","//td[@class='shippingQuantity']",Target.XPATH);
	public static final Target PRICE = new Target("price","//td[@class='shippingTotal']",Target.XPATH);
	public static final Target PLACE_ORDER_BUTTON = new Target("place-order-button","//button[@id='placeOrderBtn']",Target.XPATH);
	
	public OrderReviewPage(SiteRepository repository) {
		super(repository);
	}

	public OrderReviewPage verifyProductDetails(){
		logStep("Verify Product Image");
		getCommand().waitForTargetVisible(PRODUCT_IMAGE);
		logStep("Verify Product Title");
		getCommand().waitForTargetVisible(PRODUCT_TITLE);
		logStep("Verify Product Arrival Information");
		getCommand().waitForTargetVisible(ARRIVAL_INFORMATION);
		logStep("Verify Product Quantity");
		getCommand().waitForTargetVisible(QUANTITY);
		logStep("Verify Product PRICE");
		getCommand().waitForTargetVisible(PRICE);
		return this;
	}
	
	public OrderReviewPage clickPlaceOrderButton(){
		logStep("Click on place order button");
		
		return this;
	}
}
