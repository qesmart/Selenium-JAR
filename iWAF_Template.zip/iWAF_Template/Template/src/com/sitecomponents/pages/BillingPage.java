/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;
import com.sitecomponents.yaml.UserDetails;

public class BillingPage extends SitePage{

	public static final Target CARD_NUMBER = new Target("card-number","//input[@id='cardNumber']",Target.XPATH);
	public static final Target CARD_SECURITY_CODE = new Target("card-security-code","//form[@id='CreditCardForm']//input[@id='securityCode']",Target.XPATH);
	public static final Target MONTH_DROPDOWN = new Target("month-dropdown","//form[@id='CreditCardForm']//select[@id='expiration']",Target.XPATH);
	public static final Target SELECT_MONTH = new Target("select-month","//select[@id='expiration']//option[@value='{0}']",Target.XPATH);
	public static final Target YEAR_DROPDOWN = new Target("year-dropdown","//form[@id='CreditCardForm']//select[@id='cYear']",Target.XPATH);
	public static final Target SELECT_YEAR = new Target("select-year","//select[@id='cYear']//option[@value='{0}']",Target.XPATH);
	public static final Target NAME_ON_CARD = new Target("name-on-card","//form[@id='CreditCardForm']//input[@id='nameCard']",Target.XPATH);
	public static final Target REVIEW_ORDER = new Target("review-order","//div[@id='reviewButton']//button",Target.XPATH);
	public static final Target CARD_SECURITY_CODE_LOGGED_IN = new Target("card-security-code-logged-in","//div[@id='paymeth_cc_other']//input[@id='securityCodeSavedCC']",Target.XPATH);
	public static final Target CHOOSE_AN_ADDRESS_BUTTON = new Target("choose-an-address-button","//a[@class='chooseAnAddress shcBtn']",Target.XPATH);
	public static final Target CHOOSE_THIS_ADDRESS = new Target("choose-this-address","//div[@class='selectThisAddy']//a",Target.XPATH);
	
	public BillingPage(SiteRepository repository) {
		super(repository);
	}
	
	public BillingPage enterCardCredentials(UserDetails user){
		logStep("Enter card credentials");
		getCommand().waitForTargetVisible(CARD_NUMBER);
		getCommand().sendKeys(CARD_NUMBER, user.creditCard.cardNumber);
		getCommand().waitForTargetVisible(CARD_SECURITY_CODE);
		getCommand().sendKeys(CARD_SECURITY_CODE, user.creditCard.cardSecurityCode);
		getCommand().waitForTargetVisible(MONTH_DROPDOWN);
		getCommand().selectDropDown(MONTH_DROPDOWN, user.creditCard.cardExpiryMonth);
		getCommand().waitForTargetVisible(YEAR_DROPDOWN);
		getCommand().selectDropDown(YEAR_DROPDOWN, user.creditCard.cardExpiryYear);
		getCommand().waitForTargetVisible(NAME_ON_CARD);
		getCommand().sendKeys(NAME_ON_CARD, user.creditCard.primaryCardName);
		return this;
	}
	
	public BillingPage reviewOrder(){
		logStep("Review order");
		getCommand().waitForTargetVisible(REVIEW_ORDER);
		getCommand().click(REVIEW_ORDER);
		return this;
	}

	public BillingPage enterCardCredentialsForLoggedInUser(UserDetails user){
		logStep("Enter card credentials for logged in user");
		getCommand().waitForTargetVisible(CARD_SECURITY_CODE_LOGGED_IN);
		getCommand().clear(CARD_SECURITY_CODE_LOGGED_IN);
		getCommand().sendKeys(CARD_SECURITY_CODE_LOGGED_IN, user.creditCard.cardSecurityCode);
		return this;
	}
	
	public BillingPage chooseBillingAddressForLoggedInUser(){
		logStep("Choose Billing Address for Logged In User");
		getCommand().waitForTargetVisible(CHOOSE_AN_ADDRESS_BUTTON);
		getCommand().click(CHOOSE_AN_ADDRESS_BUTTON);
		getCommand().waitForTargetVisible(CHOOSE_THIS_ADDRESS);
		getCommand().click(CHOOSE_THIS_ADDRESS);
		return this;
		
	}
}
