/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;
import com.sitecomponents.yaml.UserDetails;

public class CheckoutPage extends SitePage {

	public static final Target CONTINUE_AS_GUEST = new Target("continue-as-guest","//label[contains(.,'Continue as a guest')]/parent::div//input",Target.XPATH);
	public static final Target EMAIL_ID_TEXTBOX = new Target("email-id-textbox","//input[@id='email_01']",Target.XPATH);
	public static final Target CONTINUE_LOGIN = new Target("continue-login","//input[@id='loginCheckoutcont']",Target.XPATH);
	public static final Target SIGN_IN_RADIO_BUTTON = new Target("sign-in-radio-button","//input[@id='pass_yes']",Target.XPATH);
	public static final Target SIGN_IN_EMAIL = new Target("sign-in-email","//input[@id='email_01']",Target.XPATH);
	public static final Target SIGN_IN_PASSWORD = new Target("sign-in-password","//input[@id='passwordB']",Target.XPATH);
	
	public CheckoutPage(SiteRepository repository) {
		super(repository);
	}

	public CheckoutPage continueAsGuest(UserDetails user){
		logStep("Click continue as guest radio buttton");
		getCommand().waitForTargetVisible(CONTINUE_AS_GUEST);
		getCommand().click(CONTINUE_AS_GUEST);
		getCommand().waitForTargetVisible(EMAIL_ID_TEXTBOX);
		getCommand().sendKeys(EMAIL_ID_TEXTBOX, user.email);
		getCommand().waitForTargetVisible(CONTINUE_LOGIN);
		getCommand().click(CONTINUE_LOGIN);
		return this;
	}
	
	public CheckoutPage signInDuringCheckout(UserDetails user){
		logStep("Sign In During Checkout");
		getCommand().waitForTargetVisible(SIGN_IN_RADIO_BUTTON);
		getCommand().click(SIGN_IN_RADIO_BUTTON);
		getCommand().waitForTargetVisible(SIGN_IN_EMAIL);
		getCommand().sendKeys(SIGN_IN_EMAIL, user.email);
		getCommand().waitForTargetVisible(SIGN_IN_PASSWORD);
		getCommand().sendKeys(SIGN_IN_PASSWORD, user.password);
		getCommand().waitForTargetVisible(CONTINUE_LOGIN);
		getCommand().click(CONTINUE_LOGIN);
		return this;
	}
}
