/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;
import com.sitecomponents.yaml.UserDetails;

public class ProfilePage extends SitePage{

	public static final Target EDIT_PERSONAL_INFO = new Target("edit-personal-info","//div[@id='dbAboutMe']//ul[@class='inlineList']//a[contains(.,'Edit')]",Target.XPATH);
	public static final Target EDIT_FIRST_NAME = new Target("edit-first-name","//input[@id[contains(.,'FirstName')]]",Target.XPATH);
	public static final Target EDIT_LAST_NAME = new Target("edit-last-name","//input[@id[contains(.,'LastName')]]",Target.XPATH);
	public static final Target EDIT_ZIPCODE = new Target("edit-zipcode","//input[@id[contains(.,'Zip')]]",Target.XPATH);
	public static final Target EDIT_PHONE = new Target("edit-phone","//input[@id[contains(.,'Phone')]]",Target.XPATH);
	public static final Target EDIT_EMAIL = new Target("edit-email","//input[@id[contains(.,'PrimaryEmail')]]",Target.XPATH);
	public static final Target SAVE_BUTTON = new Target("save-button","//button[@class='profileStandardBtn shcBtn shcBtnCTA']",Target.XPATH);
	public static final Target EDIT_ADDRESS_LINK = new Target("edit-address","//a[@class='miSavedAddressIndvEdit']",Target.XPATH);
	public static final Target EDIT_ADDRESS_FIRST_NAME = new Target("edit-address-first-name","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'FirstName')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_LAST_NAME = new Target("edit-address-last-name","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'LastName')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_STREET = new Target("edit-address-street","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'Street')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_CITY = new Target("edit-address-city","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'City')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_STATE = new Target("edit-address-state","//ul[contains(@class,'SavedAddressIndvEdit')]//select[contains(@id,'State')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_ZIPCODE = new Target("edit-address-zipcode","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'Zip')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_PHONE = new Target("edit-address-phone","//ul[contains(@class,'SavedAddressIndvEdit')]//input[contains(@id,'Phone')]",Target.XPATH);
	public static final Target EDIT_ADDRESS_SAVE_BUTTON = new Target("edit-address-save-button","//ul[contains(@class,'SavedAddressIndvEdit')]//button[contains(text(),'Save')]",Target.XPATH);
	
	public ProfilePage(SiteRepository repository) {
		super(repository);
	}

	public ProfilePage editPersonalInformation(UserDetails user){
		logStep("Edit Personal Information");
		getCommand().waitForTargetVisible(EDIT_PERSONAL_INFO);
		getCommand().click(EDIT_PERSONAL_INFO);
		getCommand().waitForTargetVisible(EDIT_FIRST_NAME);
		getCommand().clear(EDIT_FIRST_NAME);
		getCommand().sendKeys(EDIT_FIRST_NAME, user.address.firstName);
		getCommand().waitForTargetVisible(EDIT_LAST_NAME);
		getCommand().clear(EDIT_LAST_NAME);
		getCommand().sendKeys(EDIT_LAST_NAME, user.address.lastName);
		getCommand().waitForTargetVisible(EDIT_ZIPCODE);
		getCommand().clear(EDIT_ZIPCODE);
		getCommand().sendKeys(EDIT_ZIPCODE, user.address.zipCode);
		getCommand().waitForTargetVisible(EDIT_PHONE);
		getCommand().clear(EDIT_PHONE);
		getCommand().sendKeys(EDIT_PHONE, user.address.phoneNumber);
		getCommand().waitForTargetVisible(EDIT_EMAIL);
		getCommand().clear(EDIT_EMAIL);
		getCommand().sendKeys(EDIT_EMAIL, user.email);
		getCommand().waitForTargetVisible(SAVE_BUTTON);
		getCommand().click(SAVE_BUTTON);
		return this;
	}
	
	public ProfilePage editAddressInformation(UserDetails user){
		logStep("Edit Address Information");
		getCommand().waitForTargetVisible(EDIT_PERSONAL_INFO);
		getCommand().click(EDIT_PERSONAL_INFO);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_LINK);
		getCommand().click(EDIT_ADDRESS_LINK);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_FIRST_NAME);
		getCommand().clear(EDIT_ADDRESS_FIRST_NAME);
		getCommand().sendKeys(EDIT_ADDRESS_FIRST_NAME, user.address.firstName);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_LAST_NAME);
		getCommand().clear(EDIT_ADDRESS_LAST_NAME);
		getCommand().sendKeys(EDIT_ADDRESS_LAST_NAME, user.address.lastName);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_STREET);
		getCommand().clear(EDIT_ADDRESS_STREET);
		getCommand().sendKeys(EDIT_ADDRESS_STREET, user.address.addressLine1);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_CITY);
		getCommand().clear(EDIT_ADDRESS_CITY);
		getCommand().sendKeys(EDIT_ADDRESS_CITY, user.address.city);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_STATE);
		getCommand().selectDropDown(EDIT_ADDRESS_STATE, user.address.state);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_ZIPCODE);
		getCommand().clear(EDIT_ADDRESS_ZIPCODE);
		getCommand().sendKeys(EDIT_ADDRESS_ZIPCODE, user.address.zipCode);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_PHONE);
		getCommand().clear(EDIT_ADDRESS_PHONE);
		getCommand().sendKeys(EDIT_ADDRESS_PHONE, user.address.phoneNumber);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_SAVE_BUTTON);
		getCommand().click(EDIT_ADDRESS_SAVE_BUTTON);
		getCommand().waitForTargetVisible(EDIT_ADDRESS_SAVE_BUTTON);
		getCommand().click(EDIT_ADDRESS_SAVE_BUTTON);
		return this;
	}
}
