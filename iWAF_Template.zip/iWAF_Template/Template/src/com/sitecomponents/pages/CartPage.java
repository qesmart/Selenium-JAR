/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;

public class CartPage extends SitePage {

	public static final Target PROCEED_TO_CHECKOUT = new Target("proceed-to-checkout","//a[@id='proceedToCheckout']",Target.XPATH);
	public static final Target SHOPPING_CART_PRODUCT_TITLE = new Target("shopping-cart-product_title","//div[@class='product_in_cart']//a[@id[contains(.,'WC_CurrentOrderDisplayJSPF_Link_2_')]]",Target.XPATH);
	public static final Target SHOPPING_CART_PRODUCT_PRICE = new Target("shopping-cart-product_price","//div[@class='currentPrice']//span",Target.XPATH);
	public static final Target QUANTITY_TEXT_BOX = new Target("quantity-text-box","//input[@id='quantity_1']",Target.XPATH);
	public static final Target UPDATE_QUANTITY = new Target("update-quantity","//a[@class='updateQuan']",Target.XPATH);
	public static final Target SHOPPING_CART_PAGE_YOUR_CART_EMPTY_MESSAGE = new Target("shopping-cart-page-your-cart-is-empty-message","//h3[@class='alert']", Target.XPATH);
	public static final Target SHOPPING_CART_REMOVE_THIS_ITEM_LINK = new Target("shopping-cart-remove-this-item-link","//a[@class='removeItem']", Target.XPATH);
	public static final Target REMOVE_BUTTON_IN_CONFIRMATION_POPUP = new Target("remove-button-in-confirmation-popup","//button[@class='removeItem']", Target.XPATH);
	public static final Target SHOPPING_CART_PRODUCT_IMAGE = new Target("shopping-cart-product-image","//td[@class='description_item']//img", Target.XPATH);
	public static final Target SOLD_BY = new Target("sold-by","//span[@class='vendor']", Target.XPATH);
	public static final Target SHOPPING_CART_SUB_TOTAL = new Target("shopping-cart-sub-total","//div[@id='merchSubtotal']//div[contains(.,'$')]",Target.XPATH);
	public static final Target SHOPPING_CART_PRE_TAX_TOTAL = new Target("shopping-cart-pre-tax-total","//div[@id='estTotal']/div[@id='estimadedpretax_GH']",Target.XPATH);
	public static final Target ARRIVAL_METHOD = new Target("arrival-method","//ul[contains(@id,'arrivalOptions')]//a[contains(.,'{0}')]",Target.XPATH);
	public static final Target CHOOSE_THIS_STORE = new Target("choose-this-store","//a[@class='selectThisStore']",Target.XPATH);
	public static final Target CURRENT_ZIPCODE = new Target("current-zipcode","//div[@class='currentStore']//a[@class='ffmentLoc']",Target.XPATH);
	public static final Target ENTER_NEW_ZIPCODE = new Target("enter-new-zipcode","//input[@id='ffmentNewAddy']",Target.XPATH);
	public static final Target GO_BUTTON = new Target("go-button","//a[@class='submitAddy']",Target.XPATH);
	
	public CartPage(SiteRepository repository) {
		super(repository);
	}

	public CartPage clickProceedToCheckOut(){
		logStep("Click Proceed to checkout buttton");
		getCommand().waitForTargetVisible(PROCEED_TO_CHECKOUT);
		getCommand().click(PROCEED_TO_CHECKOUT);
		return this;
	}
	
	public CartPage verifyProductInCart() {
		logStep("Verify product in cart page.");
		String prd = (String) getCommand().retrieveValue("productTitle");
		logStep("Verify product title.");
		String prodTitle = getCommand().getText(SHOPPING_CART_PRODUCT_TITLE);
			if (prd.contains(prodTitle)) {
			logStep("Product title is verified: " + prodTitle);
		} else {
			logStep("Product title mismatch found in cart page and product detail page");
		}
		String price=(String) getCommand().retrieveValue("productPrice");
		String priceAtCart=getCommand().getText(SHOPPING_CART_PRODUCT_PRICE);
		if (price.equals(priceAtCart)) {
			logStep("Product price is verified: $" + price);
		} else {
			logStep("Price mismatch found in cart page and product detail page");
		}
		return this;
	}
	
	public CartPage updateQuantityInCartPage(String quantity){
		logStep("Update product quantity");
		getCommand().waitForTargetVisible(QUANTITY_TEXT_BOX);
		getCommand().clear(QUANTITY_TEXT_BOX);
		getCommand().sendKeys(QUANTITY_TEXT_BOX, quantity);
		getCommand().click(UPDATE_QUANTITY);
		return this;
	}
	
	public CartPage removeAllItemsFromCart() {		
		logStep("Remove all items from cart.");
		if(!getCommand().isTargetVisibleAfterWait(SHOPPING_CART_PAGE_YOUR_CART_EMPTY_MESSAGE)) {
			int itemsCountInCart = getCommand().getTargetCount(SHOPPING_CART_REMOVE_THIS_ITEM_LINK);
			for (int i=1; i<=itemsCountInCart; i++) {
				if (getCommand().isTargetVisibleAfterWait(SHOPPING_CART_REMOVE_THIS_ITEM_LINK)) {
					getCommand().click(SHOPPING_CART_REMOVE_THIS_ITEM_LINK);
					}
					getCommand().waitForTargetVisible(REMOVE_BUTTON_IN_CONFIRMATION_POPUP);
					getCommand().click(REMOVE_BUTTON_IN_CONFIRMATION_POPUP);
				}
			}
		return this;
	}	
	
	public void verifyProductDetailsOnCartPage() {
		getCommand().waitForTargetVisible(SHOPPING_CART_PRODUCT_TITLE);
		String productTitle = getCommand().getText(SHOPPING_CART_PRODUCT_TITLE);
		logStep( ("Verify basic details of: " + productTitle));
		getCommand().waitForTargetVisible(SHOPPING_CART_PRODUCT_IMAGE);
		logStep( "Product image is present");
		getCommand().waitForTargetVisible(SOLD_BY);
		logStep( "Vendor name is present");
		getCommand().waitForTargetVisible(QUANTITY_TEXT_BOX);
		logStep( "Quantity textbox is present");
		getCommand().click(QUANTITY_TEXT_BOX);
		getCommand().waitFor(2);
		getCommand().waitForTargetVisible(UPDATE_QUANTITY);
		logStep( "Update quantity link is present.");
		getCommand().waitForTargetVisible(SHOPPING_CART_REMOVE_THIS_ITEM_LINK);
		logStep( "Remove item link is present");
	}
	
	public void verifySubTotalAndOtherLinks() {
		String subTotal, preTaxTotal;
		logStep( "Verify whether Subtotal and pre tax total links are displayed");
		getCommand().waitForTargetVisible(SHOPPING_CART_SUB_TOTAL);
		subTotal =getCommand().getText(SHOPPING_CART_SUB_TOTAL);
		logStep(("Subtotal is displayed - " + subTotal));
		getCommand().waitForTargetVisible(SHOPPING_CART_PRE_TAX_TOTAL);
		preTaxTotal = getCommand().getText(SHOPPING_CART_PRE_TAX_TOTAL);
		logStep(("Pre tax total is displayed - " + preTaxTotal));
	}
	
	public CartPage changeArrivalMethod(String arrivalMethod){
		logStep("Change arrival method on cart page");
		getCommand().waitForTargetVisible(ARRIVAL_METHOD.format(arrivalMethod));
		getCommand().click(ARRIVAL_METHOD.format(arrivalMethod));
		if(arrivalMethod.equalsIgnoreCase("Pickup"))
		{
			getCommand().waitForTargetVisible(CHOOSE_THIS_STORE);
			getCommand().click(CHOOSE_THIS_STORE);
		}
		return this;
	}
	
	public CartPage changeZipCodeForPickp(String zipcode){
		logStep("Change zip code for pickup for changing arrival method");
		getCommand().waitForTargetVisible(CURRENT_ZIPCODE);
		getCommand().click(CURRENT_ZIPCODE);
		getCommand().waitForTargetVisible(ENTER_NEW_ZIPCODE);
		getCommand().clear(ENTER_NEW_ZIPCODE);
		getCommand().sendKeys(ENTER_NEW_ZIPCODE, zipcode);
		return this;
	}
}
