/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.sitecomponents.repository.SiteRepository;
import com.sitecomponents.yaml.UserDetails;
import com.iwaf.framework.components.Target;

public class HomePage extends SitePage{

	public static final Target SITE_LOGO = new Target("site-logo","//div[@id='logo']//a",Target.XPATH);
	public static final Target SIGN_IN_LINK = new Target("sign-in-link","//a[@id='signInLink']",Target.XPATH);
	public static final Target EMAIL_FOR_LOGIN = new Target("email-for-login","//input[@id='email']",Target.XPATH);
	public static final Target PASSWORD_FOR_LOGIN = new Target("password-for-login","//input[@id='password']",Target.XPATH);
	public static final Target IFRAME = new Target("iframe","//div[@id='modalIframe']//iframe[@src[contains(.,'login')]]",Target.XPATH);
	public static final Target SIGN_IN_BUTTON = new Target("sign-in-button","//button[contains(@class,'signIn')]",Target.XPATH);
	public static final Target REGISTER_LINK = new Target("register-link","//a[@id='registerLink']",Target.XPATH);
	public static final Target CART_LINK = new Target("cart-link","//a[@id='myCart']",Target.XPATH);
	public static final Target SEARCH_TEXTBOX = new Target("search-textbox", "//input[@id='keyword']", Target.XPATH);
	public static final Target MY_PROFILE_LINK = new Target("my-profile-link", "//a[@id='myProfile']", Target.XPATH);
	public static final Target MY_PROFILE = new Target("my-profile", "//a[contains(.,'My Profile')]", Target.XPATH);
	public static final Target REGISTER_EMAIL_INPUT = new Target("register-email-input", "//form[@id='regform']//input[@id='email']", Target.XPATH);
	public static final Target REGISTER_EMAIL_INPUT_CONFIRM = new Target("register-email-input-confirm", "//form[@id='regform']//input[@id='emailConfirm']", Target.XPATH);
	public static final Target REGISTER_PASSWORD = new Target("register-password", "//form[@id='regform']//input[@id='password']", Target.XPATH);
	public static final Target REGISTER_FIRST_NAME = new Target("register-first-name", "//form[@id='regform']//input[@id='fname']", Target.XPATH);
	public static final Target REGISTER_LAST_NAME = new Target("register-last-name", "//form[@id='regform']//input[@id='lname']", Target.XPATH);
	public static final Target REGISTER_ZIPCODE = new Target("register-zipcode", "//form[@id='regform']//input[@id='zip']", Target.XPATH);
	public static final Target REGISTER_BUTTON = new Target("register-button", "//button[@class='shcBtn shcBtnCTA continueSignIn']", Target.XPATH);
	
	public HomePage(SiteRepository repository){
		super(repository);
	}

	public HomePage atHomePage(){
		logStep("Site's HomePage Launched");
		return this;
	}
	
	public HomePage verifyHomePage(){
		logStep("Verify the Site Logo");
		getCommand().waitForTargetPresent(SITE_LOGO);
		return this;
	}
	
	public HomePage signIn(){
		logStep("Sign In");
		UserDetails user = UserDetails.fetch("UserDetails");
		getCommand().waitForTargetVisible(SIGN_IN_LINK);
		getCommand().click(SIGN_IN_LINK);
		getCommand().waitFor(10);
		getCommand().waitForTargetVisible(IFRAME);
		getCommand().selectFrame(IFRAME);
		getCommand().waitForTargetVisible(EMAIL_FOR_LOGIN);
		getCommand().sendKeys(EMAIL_FOR_LOGIN, user.email);
		getCommand().waitForTargetVisible(PASSWORD_FOR_LOGIN);
		getCommand().sendKeys(PASSWORD_FOR_LOGIN, user.password);
		getCommand().waitForTargetVisible(SIGN_IN_BUTTON);
		getCommand().click(SIGN_IN_BUTTON);
		return this;
	}
	
	public HomePage goToMyProfile() {
		logStep("Click on MyProfile link");
		getCommand().waitForTargetVisible(MY_PROFILE_LINK);
		getCommand().mouseHover(MY_PROFILE_LINK);
		getCommand().waitForTargetVisible(MY_PROFILE);
		getCommand().click(MY_PROFILE);
		return this;
	}
	
	public HomePage verifyHomePageHeaderLinks() {
		logStep("Verify Home Page header Links");
		getCommand().waitForTargetVisible(SITE_LOGO);
		logStep("Sears Logo is present");
		getCommand().waitForTargetVisible(SIGN_IN_LINK);
		logStep("'Sign In' link is present");
		getCommand().waitForTargetVisible(REGISTER_LINK);
		logStep("'Register' link is present");
		getCommand().waitForTargetVisible(CART_LINK);
		logStep("Cart image is present");
		getCommand().waitForTargetVisible(SEARCH_TEXTBOX);
		logStep("Search text box is present");
		return this;
	}
	
	public HomePage gotoSiteHomePage(){
		logStep("Click on Site logo to go to Home Page ");
		getCommand().waitForTargetVisible(SITE_LOGO);
		getCommand().click(SITE_LOGO);
		return this;
	}
	
	public HomePage registerNewUser(UserDetails user){
		logStep( "Register a new user");
		getCommand().waitForTargetVisible(REGISTER_LINK);
		getCommand().waitForTargetVisible(IFRAME);
		getCommand().selectFrame(IFRAME);
		getCommand().waitForTargetVisible(REGISTER_EMAIL_INPUT);
		getCommand().sendKeys(REGISTER_EMAIL_INPUT, user.email);
		getCommand().waitForTargetVisible(REGISTER_EMAIL_INPUT_CONFIRM);
		getCommand().sendKeys(REGISTER_EMAIL_INPUT_CONFIRM, user.email);
		getCommand().waitForTargetVisible(REGISTER_PASSWORD);
		getCommand().sendKeys(REGISTER_PASSWORD, user.password);
		getCommand().waitForTargetVisible(REGISTER_FIRST_NAME);
		getCommand().sendKeys(REGISTER_FIRST_NAME, user.address.firstName);
		getCommand().waitForTargetVisible(REGISTER_LAST_NAME);
		getCommand().sendKeys(REGISTER_LAST_NAME, user.address.lastName);
		getCommand().waitForTargetVisible(REGISTER_ZIPCODE);
		getCommand().sendKeys(REGISTER_ZIPCODE, user.address.zipCode);
		getCommand().waitForTargetVisible(REGISTER_BUTTON);
		getCommand().click(REGISTER_BUTTON);
		return this;
	}
}