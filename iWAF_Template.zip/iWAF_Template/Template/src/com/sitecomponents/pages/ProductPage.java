/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;

public class ProductPage extends SitePage {

	public static final Target PRODUCT_TITLE = new Target("product-title","//h1[@itemprop='name']",Target.XPATH);
	public static final Target ARRIVAL_METHOD_RADIO_BUTTON = new Target("arrival-method-radio-button","//input[contains(@id,'{0}')]",Target.XPATH);
	public static final Target ADD_TO_CART_BUTTON = new Target("add-to-cart","//a[@id='addCart']",Target.XPATH);
	public static final Target PRODUCT_ID = new Target("product-id","//span[@itemprop='productID']",Target.XPATH);
	public static final Target PRODUCT_IMAGE = new Target("product-image","//div[@id='productMainImage']",Target.XPATH);
	public static final Target PRODUCT_PRICE = new Target("product-price","//div[@class='youPay']//span[@class='pricing']",Target.XPATH);
	public static final Target VIEW_CART_AND_CHECKOUT_BUTTON = new Target("view-cart-and-checkout-button","//div[@id='confirmCheckout']",Target.XPATH);
	public static final Target CONTINUE_SHOPPING = new Target("continue-shopping","//div[@id='confirmKeepShopping']",Target.XPATH);
	
	public ProductPage(SiteRepository repository) {
		super(repository);
	}

	
	
	public ProductPage selectArrivalMethod(String arrivalMethod) {
		logStep("Select arrival method for product");
		String productTitle=getCommand().getText(PRODUCT_TITLE);
		String productPrice=getCommand().getText(PRODUCT_PRICE);
		getCommand().storeValue("productTitle", productTitle);
		getCommand().storeValue("productPrice", productPrice);
		getCommand().waitForTargetVisible(ARRIVAL_METHOD_RADIO_BUTTON.format(arrivalMethod));
		getCommand().click(ARRIVAL_METHOD_RADIO_BUTTON.format(arrivalMethod));
		return this;
	} 
	
	public ProductPage addToCart() {
		logStep("Click add to cart");
		getCommand().waitForTargetVisible(ADD_TO_CART_BUTTON);
		getCommand().click(ADD_TO_CART_BUTTON);
		getCommand().waitForTargetVisible(VIEW_CART_AND_CHECKOUT_BUTTON);
		getCommand().click(VIEW_CART_AND_CHECKOUT_BUTTON);
		return this;
	} 
	
	public ProductPage verifyProductPage(){
		logStep("Verify Product Page");
		getCommand().waitForTargetVisible(PRODUCT_ID);
		logStep("Product ID is verified in Product Page");
		getCommand().waitForTargetVisible(PRODUCT_TITLE);
		logStep("Product title is verified in Product Page");
		getCommand().waitForTargetVisible(PRODUCT_IMAGE);
		logStep("Product Image is verified in Product Page");
		getCommand().waitForTargetVisible(PRODUCT_PRICE);
		logStep("Product price is verified in Product Page");
		getCommand().waitForTargetVisible(ADD_TO_CART_BUTTON);
		logStep("Add to Cart button is verified in Product Page");
		return this;
	}
	
	public ProductPage addToCartAndContinueShopping(){
		logStep("Add To Cart and continue shopping");
		getCommand().waitForTargetVisible(ADD_TO_CART_BUTTON);
		getCommand().click(ADD_TO_CART_BUTTON);
		getCommand().waitForTargetVisible(CONTINUE_SHOPPING);
		getCommand().click(CONTINUE_SHOPPING);
		return this;
	}
}
