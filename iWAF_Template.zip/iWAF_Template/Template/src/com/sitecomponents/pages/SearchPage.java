/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;

public class SearchPage extends SitePage {

	public static final Target SEARCH_TEXTBOX = new Target("search-textbox", "//input[@id='keyword']", Target.XPATH);
	public static final Target SEARCH_BUTTON = new Target("search-button", "//input[@id='goBtn']", Target.XPATH);
	public static final Target PRODUCT_TITLE = new Target("product-title","//h4[@itemprop='name']//a",Target.XPATH);
	public static final Target ITEM_COUNT = new Target("item-count","//div[@id='nmbProdItems']//span",Target.XPATH);
	
	public SearchPage(SiteRepository repository) {
		super(repository);
	}

	public SearchPage searchProductByKeyword(String keyword){
		logStep("Search for keyword <B>"+keyword+"</B> from home page");
		getCommand().waitForTargetPresent(SEARCH_TEXTBOX);
		getCommand().sendKeys(SEARCH_TEXTBOX, keyword);
		getCommand().click(SEARCH_BUTTON);
		
		return this;
	}
	
	public SearchPage selectFirstProduct() {
		logStep("Click on product title and go to product page");
		getCommand().waitForTargetVisible(PRODUCT_TITLE);
		getCommand().click(PRODUCT_TITLE);
		return this;
	} 
	
	public SearchPage getCountOfProducts(){
		logStep("Verify search product items");
		getCommand().waitForTargetVisible(ITEM_COUNT);
		String itemCount=getCommand().getText(ITEM_COUNT).substring(10,13);
		return this;
	}
}
