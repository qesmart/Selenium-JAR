/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.BasePage;
import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;

public class CategoryPage extends SitePage {

	public static final Target VERTICAL_LINK = new Target("vertical-link", "//a[contains(text(),'{0}')]", Target.XPATH);
	public static final Target CATEGORY_LINK = new Target("category-link", "//a[contains(text(),'{0}')]", Target.XPATH);
	public static final Target SUB_CATEGORY_LINK = new Target("sub-category-link", "//a[contains(text(),'{0}')]", Target.XPATH);
	public static final Target BRAND_FILTER = new Target("brand-filter", "//a[@id='Brand']", Target.XPATH);
	public static final Target COLOR_FAMILY_FILTER = new Target("color-family_FILTER", "//a[@id='ColorFamily']", Target.XPATH);
	public static final Target PRICE_FILTER = new Target("price-family", "//a[@id='Price']", Target.XPATH);
	
	public CategoryPage(SiteRepository repository) {
		super(repository);
	}

	public CategoryPage selectVertical(String vertical) {
		logStep("Select Vertical: "+ vertical);
		BasePage obj = new BasePage();
		String verticalId = obj.getCommand().loadYaml(vertical, "data-pool/VerticalId.yaml");
		getCommand().waitForTargetVisible(VERTICAL_LINK.format(verticalId));
		getCommand().click(VERTICAL_LINK.format(verticalId));
		return this;
	}
	
	public CategoryPage selectCategory(String category) {
		logStep("Select Category: "+ category);
		BasePage obj = new BasePage();
		String categoryId = obj.getCommand().loadYaml(category, "data-pool/VerticalId.yaml");
		getCommand().waitForTargetVisible(CATEGORY_LINK.format(categoryId));
		getCommand().click(CATEGORY_LINK.format(categoryId));
		return this;
	}
	
	public CategoryPage selectSubCategory(String subCategory) {
		logStep("Select SubCategory: "+ subCategory);
		BasePage obj = new BasePage();
		String categoryId = obj.getCommand().loadYaml(subCategory, "data-pool/VerticalId.yaml");
		getCommand().waitForTargetVisible(SUB_CATEGORY_LINK.format(categoryId));
		getCommand().click(SUB_CATEGORY_LINK.format(categoryId));
		return this;
	}
	
	public CategoryPage verifyFilters(){ 
		logStep("Verify Brand name filter");
		getCommand().waitForTargetVisible(BRAND_FILTER);
		logStep("Verify Color filter");
		getCommand().waitForTargetVisible(COLOR_FAMILY_FILTER);
		logStep("Verify price filter");
		getCommand().waitForTargetVisible(PRICE_FILTER);
		return this;
	}
	
	
}
