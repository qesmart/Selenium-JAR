/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.sitecomponents.repository.SiteRepository;
import com.iwaf.framework.BasePage;

public class SitePage extends BasePage{
	protected SiteRepository repository;
	
	SitePage(SiteRepository repository){
		this.repository=repository;
	}

	public HomePage _AtHomePage() {
		return this.repository.homePage();
	}
	
	public SearchPage _AtSearchPage() {
		return this.repository.searchPage();
	}
	
	public ProductPage _AtProductPage() {
		return this.repository.productPage();
	}
	
	public CartPage _AtCartPage() {
		return this.repository.cartPage();
	}
	
	public BillingPage _AtBillingPage() {
		return this.repository.billingPage();
	}
	
	public OrderReviewPage _AtOrderReviewPage() {
		return this.repository.orderReviewPage();
	}
	
	public ProfilePage _AtProfilePage() {
		return this.repository.profilePage();
	}
	
	public ShippingPage _AtShippingPage() {
		return this.repository.shippingPage();
	}
	
	public CheckoutPage _AtCheckoutPage() {
		return this.repository.checkoutPage();
	}
	
	public AddressPage _AtAddressPage() {
		return this.repository.addressPage();
	}
	
	public CategoryPage _AtCategoryPage() {
		return this.repository.categoryPage();
	}
}