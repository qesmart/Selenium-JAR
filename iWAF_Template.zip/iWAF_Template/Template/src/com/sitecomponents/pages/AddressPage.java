/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.pages;

import com.iwaf.framework.components.Target;
import com.sitecomponents.repository.SiteRepository;
import com.sitecomponents.yaml.UserDetails;

public class AddressPage extends SitePage {

	public static final Target FIRST_NAME = new Target("first-name","//input[contains(@name,'firstName')]",Target.XPATH);
	public static final Target LAST_NAME = new Target("last-name","//input[contains(@name,'lastName')]",Target.XPATH);
	public static final Target ADDRESS_LINE1 = new Target("address-line1","//input[contains(@name,'address1')]",Target.XPATH);
	public static final Target CITY = new Target("city","//input[contains(@name,'city')]",Target.XPATH);
	public static final Target STATE_DROPDOWN = new Target("state-dropdown","//select[contains(@name,'state')]",Target.XPATH);
	public static final Target SELECT_STATE = new Target("select-state","//select[contains(@name,'state')]//option[@value='{0}']",Target.XPATH);
	public static final Target ZIPCODE = new Target("zipcode","//input[contains(@name,'zipCode')]",Target.XPATH);
	public static final Target PHONE_NUMBER = new Target("phone-number","//input[contains(@name,'day1')]",Target.XPATH);
	public static final Target SAME_AS_DELIVERY_ADDRESS_CHECKBOX = new Target("same-as-delivery-address-checkbox","//input[contains(@name,'billingAddressCheckBox')]",Target.XPATH);
	public static final Target CONTINUE_TO_SHIPPING = new Target("continue-to-shipping","//button[contains(text(),'Continue')]",Target.XPATH);
	
	public AddressPage(SiteRepository repository) {
		super(repository);
	}

	public AddressPage fillAddressForm(UserDetails user){
		logStep("Fill address form");
		getCommand().waitForTargetVisible(FIRST_NAME);
		getCommand().sendKeys(FIRST_NAME, user.address.firstName);
		getCommand().waitForTargetVisible(LAST_NAME);
		getCommand().sendKeys(LAST_NAME, user.address.lastName);
		getCommand().waitForTargetVisible(ADDRESS_LINE1);
		getCommand().sendKeys(ADDRESS_LINE1, user.address.addressLine1);
		getCommand().waitForTargetVisible(CITY);
		getCommand().sendKeys(CITY, user.address.city);
		getCommand().waitForTargetVisible(STATE_DROPDOWN);
		getCommand().waitForTargetVisible(SELECT_STATE.format(user.address.state));
		getCommand().selectDropDown(STATE_DROPDOWN, user.address.state);
		getCommand().waitForTargetVisible(ZIPCODE);
		getCommand().clear(ZIPCODE);
		getCommand().sendKeys(ZIPCODE, user.address.zipCode);
		getCommand().waitForTargetVisible(PHONE_NUMBER);
		getCommand().sendKeys(PHONE_NUMBER, user.address.phoneNumber);
		getCommand().waitForTargetVisible(SAME_AS_DELIVERY_ADDRESS_CHECKBOX);
		getCommand().click(SAME_AS_DELIVERY_ADDRESS_CHECKBOX);
		return this;
	}
	
	public AddressPage continueToShippingPage(){
		logStep("Continue to shipping page");
		getCommand().waitForTargetVisible(CONTINUE_TO_SHIPPING);
		getCommand().click(CONTINUE_TO_SHIPPING);
		return this;
	}
}
