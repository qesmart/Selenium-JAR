/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.repository;

import com.sitecomponents.pages.AddressPage;
import com.sitecomponents.pages.BillingPage;
import com.sitecomponents.pages.CartPage;
import com.sitecomponents.pages.CategoryPage;
import com.sitecomponents.pages.CheckoutPage;
import com.sitecomponents.pages.HomePage;
import com.sitecomponents.pages.OrderReviewPage;
import com.sitecomponents.pages.ProductPage;
import com.sitecomponents.pages.ProfilePage;
import com.sitecomponents.pages.SearchPage;
import com.sitecomponents.pages.ShippingPage;

public class SiteRepository{

	public HomePage homePage(){
		return new HomePage(this);
	}
	
	public SearchPage searchPage(){
		return new SearchPage(this);
	}
	
	public ProductPage productPage(){
		return new ProductPage(this);
	}
	
	public CartPage cartPage(){
		return new CartPage(this);
	}
	
	public BillingPage billingPage(){
		return new BillingPage(this);
	}
	
	public OrderReviewPage orderReviewPage(){
		return new OrderReviewPage(this);
	}
	
	public ProfilePage profilePage(){
		return new ProfilePage(this);
	}
	
	public ShippingPage shippingPage(){
		return new ShippingPage(this);
	}
	
	public CheckoutPage checkoutPage(){
		return new CheckoutPage(this);
	}
	
	public AddressPage addressPage(){
		return new AddressPage(this);
	}
	
	public CategoryPage categoryPage(){
		return new CategoryPage(this);
	}
}