/**
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 *																																		   	*
 * 2011-2012 Infosys Limited, Banglore, India. All Rights Reserved																			*
 * Version: 2.0																																*
 * 																																			*
 * Except for any free or open source software components embedded in this Infosys proprietary software program ("Program"),				*
 * this Program is protected by copyright laws, international treaties and other pending or existing intellectual property rights in India, *
 * the United States and other countries. Except as expressly permitted, any unautorized reproduction, storage, transmission 				*
 * in any form or by any means (including without limitation electronic, mechanical, printing, photocopying, recording or otherwise), 		*
 * or any distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, 							*
 * and will be prosecuted to the maximum extent possible under the law 																		*
 *																																			*
 ********************************************************************************************************************************************
 ********************************************************************************************************************************************
 **/
package com.sitecomponents.yaml;

import com.iwaf.framework.utils.DataReader;

public class VerticalId {
    public static String JEWELRY ="Jewelry & Watches";
	public static String APPLIANCES = "Appliances";    
    public static String FITNESSEANDSPORTS = "Fitness & Sports";
    public static String SHOPDEPARTMENTS = "Shop Departments";
    public static String FOODGROCESSARY = "Food & Grocessary";
    public static String GIFTIDEAS = "Gift Ideas";
    public static String HER = "Her";
    public static String BEVERAGES = "Beverages";
    public static String ALL = "All";
    public static String FITNESS = "FITNESS";
    public static String ELECTRONICSANDCOMPUTERS = "Computers & Electronics";
    public static String IPODSANDMP3PLAYERS = "IPODSANDMP3PLAYERS";
    public static String IPODS = "IPODS";
    public static String INVERSION="INVERSION";
    public static String INVERSION_ACCESSORIES="INVERSION_ACCESSORIES";
    public static String REFRIGERATORS="REFRIGERATORS";
    public static String COMPACT_REFRIGERATORS="COMPACT_REFRIGERATORS";
    public static String DISHWASHERS="DISHWASHERS";
    public static String BUILT_IN_DISHWASHERS="BUILT_IN_DISHWASHERS";
	public static String BED_BATH_HOME  = "Bed & Bath";  
    public static String BED_TOWEL_RUG="BED_TOWEL_RUG";
    public static String BATH_RUGS_MATS="BATH_RUGS_MATS";
    public static String BATH_RUGS_WRAPS="BATH_RUGS_WRAPS";
    public static String BED_UTILITY_HARDWARE="BED_UTILITY_HARDWARE";
    public static String HOOKS_RODS="HOOKS_RODS";
    public static String LAPTOPS = "LAPTOPS"; 
    public static String TABLETS = "TABLETS";
    public static String NETBOOKS = "Netbooks";
    public static String COMPUTERS = "Computers";
    public static String ALL_LAPTOPS = "All_Laptops";
    public static String COMPUTERSANDELCTRONICS = "COMPUTERSANDELCTRONICS";
    public static String ELECTRONICSANDOFFICE = "Electronics & Office";
    public static String MP3PLAYER = "MP3 Players";
    public static String PORTABLE="PORTABLE";  
    public static String BEDROOM="BEDROOM";
    public static String COLLECTIONS="COLLECTIONS";
    public static String DESKTOPS = "Desktops"; 
    public static String ALL_DESKTOPS = "All Desktops";
    
    public static String find(String verticalId){
    	return new DataReader<String>().find("VerticalId.yaml",verticalId);
    	
    }
    }
